---
name: IE Daily Control import
description: Durable notes for running an imported AI Studio React tracker in the artifact workspace.
---

Imported AI Studio trackers may bundle an Express/Vite server and frontend-owned API routes. In the artifact workspace, `/api/*` is reserved for the shared API service, so bundled endpoints should use root-level routes and the client should call those paths.

**Why:** The shared proxy sends `/api/*` to the API artifact; leaving bundled routes under `/api` makes the frontend appear healthy while AI actions fail with a proxy error.

**How to apply:** When importing a self-contained app with its own server, run that server in the web artifact workflow, use the managed `PORT`, and keep its private endpoints outside `/api`.